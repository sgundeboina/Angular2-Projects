EF6 in the Enterprise
Module 1 BEFORE

if you are following along with the module, after creating the first MVC project from a Visual Studio template, you will see that the solution requires a folder with the domain classes called Models. You'll find this folder here to add in to your solution.