EF6 in the Enterprise: Module 1 After
MvcSimpleRepo is the state of the solution after I have done a few refactorings and have a simple repository. I've included logic in here to create and seed a database if you want to run the app.

Note that the later demos in the module reflect things you will learn in later modules so they are not included as part of Module 1 demos.