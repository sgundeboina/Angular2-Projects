﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace ReusableGenericRepository
{
  public class GenericRepository<TEntity> where TEntity : class
  {
    internal DbContext _context;
    internal DbSet<TEntity> _dbSet;

    public GenericRepository(DbContext context) {
      _context = context;
      _dbSet = context.Set<TEntity>();
    }

    public IEnumerable<TEntity> All() {
      return _dbSet.AsNoTracking().ToList();
    }

    public IQueryable<TEntity> AllQuery() {
      return _dbSet.AsNoTracking();
    }
    public TEntity FindByKey(int id) {
      return _dbSet.Find(id);
    }

    public void Insert(TEntity entity) {
      _dbSet.Add(entity);
    }

    public void Update(TEntity entity) {
      _dbSet.Attach(entity);
      _context.Entry(entity).State = EntityState.Modified;
    }

    public void Delete(int id) {
      var entity = FindByKey(id);
      _dbSet.Remove(entity);
    }
  }
}