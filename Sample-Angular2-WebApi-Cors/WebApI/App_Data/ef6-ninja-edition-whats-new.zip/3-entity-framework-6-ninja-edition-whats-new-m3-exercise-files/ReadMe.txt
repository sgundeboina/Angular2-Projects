This solution (before and after) require you to rebuild to retrieve the relevant nuget package. That means you'll need to be online when building.

