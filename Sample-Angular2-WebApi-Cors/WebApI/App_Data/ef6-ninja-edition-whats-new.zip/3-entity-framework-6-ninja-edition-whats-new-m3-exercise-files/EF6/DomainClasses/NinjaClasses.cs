﻿using System;
using System.Collections.Generic;

namespace DomainClasses
{
    //http://en.wikipedia.org/wiki/Ninja

    public class Ninja
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public NinjaType NinjaType { get; set; }
        public bool ServedInOniwaban { get; set; }
        public MilitaryRole MilitaryRole { get; set; }
        public int MiltaryRoleId { get; set; }
        public Clan Clan { get; set; }
        public List<NinjaEquipment> EquipmentOwned { get; set; }

    }

    public enum NinjaType
    {
        Shinobi = 1,
        Kunoichi = 2

    }
    public class Clan
    {
        public string ClanName { get; set; }
        
    }
    public class MilitaryRole {

        public string Name { get; set; }
    }
    public class NinjaEquipment {
        public int Id { get; set; }
        public string Name { get; set; }
        enum EquipmentType
        {
            Tool=1,
            Weapon=2,
            Outwear=3
        }
    }
    public class Battle
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateRange StartEndDates { get; set; }
    }

    public class DateRange
    {
        public DateRange(DateTime start,DateTime end) {
            StartDate = start;
            EndDate = end;
        }
        public DateTime StartDate { get;private set; }
        public DateTime EndDate { get; private set; }
        
    }


}
