﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using DomainClasses;
using EF6DataLayer;

namespace ConsoleApplication1
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      EntityFrameworkProfilerBootstrapper.PreStart();
      Database.SetInitializer<NinjaContext>(null);
      WarmupQuery();

      ExecuteLinqWithSmallArray();
      ExecuteLinqWithMediumArray();
      ExecuteLinqWithLargeArray();
    }

    public static void WarmupQuery()
    {
      using (var context = new NinjaContext())
      {
        int result = context.Ninjas.Count();
      }
    }

    public static void ExecuteLinqWithSmallArray()
    {
      var listOfIdsToSearchFor = new[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

      using (var context = new NinjaContext())
      {
        Ninja[] results = context.Ninjas.Where(n => listOfIdsToSearchFor.Contains(n.Id)).ToArray();
      }
    }

    public static void ExecuteLinqWithMediumArray()
    {
      var listOfIdsToSearchFor = new List<int>();
      for (int i = 0; i < 1000; i++)
      {
        listOfIdsToSearchFor.Add(i);
      }

      using (var context = new NinjaContext())
      {
        Ninja[] results = context.Ninjas.Where(n => listOfIdsToSearchFor.Contains(n.Id)).ToArray();
      }
    }

    public static void ExecuteLinqWithLargeArray()
    {
      var listOfIdsToSearchFor = new List<int>();
      for (int i = 0; i < 10000; i++)
      {
        listOfIdsToSearchFor.Add(i);
      }

      using (var context = new NinjaContext())
      {
        Ninja[] results = context.Ninjas.Where(n => listOfIdsToSearchFor.Contains(n.Id)).ToArray();
      }
    }
  }
}