﻿using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using EF6DataLayer;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleApplication1
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void CanExecuteMostBasicOfQueries()
    {
      using (var context = new NinjaContext())
      {
        Assert.IsNotNull(context.Ninjas.ToList());
      }
    }

    [TestMethod, TestCategory("Connection Resiliency")]
    public void CanQuerySqlAzureDb()
    {
      using (var context = new NinjaContext("CloudNinjas"))
      {
        Assert.IsNotNull(context.Ninjas.ToList());
      }
    }


    [TestMethod]
    public void ExecuteLinqWithSmallContains()
    {
      var listOfIdsToSearchFor = new[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

      using (var context = new NinjaContext())
      {
        Assert.IsNotNull(context.Ninjas.Where(n => listOfIdsToSearchFor.Contains(n.Id)).ToArray());
      }
    }

    [TestMethod]
    public void ExecuteLinqWithLargeContains()
    {
      var listOfIdsToSearchFor = new List<int>();
      for (int i = 0; i < 1000; i++)
      {
        listOfIdsToSearchFor.Add(i);
      }

      using (var context = new NinjaContext())
      {
        Assert.IsNotNull(context.Ninjas.Where(n => listOfIdsToSearchFor.Contains(n.Id)).ToArray());
      }
    }

    [TestMethod, TestCategory("Reuse Open Connection")]
    public void CanInstantiateContextWithOpenConnection()
    {
      DbConnection conn;
      using (var context = new NinjaContext())
      {
        conn = context.Database.Connection;
        conn.Open();
        context.Ninjas.ToList();
      }
      //new NinjaContext(conn, false);

      Assert.IsTrue(true);
    }
  }
}