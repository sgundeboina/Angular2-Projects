﻿using System.Data.Common;
using System.Data.Entity.Infrastructure.Interception;
using System.Diagnostics;
using SqlExceptions;

namespace EF6DataLayer
{
    public class TransientFailureCausingCommandInterceptor : IDbCommandInterceptor
    {

        public void NonQueryExecuting(
          DbCommand command, DbCommandInterceptionContext<int> interceptionContext)
        {
        }

        public void NonQueryExecuted(
          DbCommand command, DbCommandInterceptionContext<int> interceptionContext)
        {
        }

        public void ReaderExecuting(
          DbCommand command, DbCommandInterceptionContext<DbDataReader> interceptionContext)
        {
            if (!(command.CommandText.Contains("serverproperty")
              || command.CommandText.Contains("_MigrationHistory")))
            {
                Debug.WriteLine("throwing fake exception from interceptor");
                throw SqlExceptionFaker.Error10053;
            }
        }

        public void ReaderExecuted(
          DbCommand command, DbCommandInterceptionContext<DbDataReader> interceptionContext)
        {

        }

        public void ScalarExecuting(
          DbCommand command, DbCommandInterceptionContext<object> interceptionContext)
        {

        }

        public void ScalarExecuted(
          DbCommand command, DbCommandInterceptionContext<object> interceptionContext)
        {

        }

        private void LogIfNonAsync<TResult>(DbCommand command, DbCommandInterceptionContext<TResult> interceptionContext)
        {

        }


    }
}