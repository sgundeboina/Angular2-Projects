﻿using System.Data.Entity;
using DomainClasses;

namespace EF6DataLayer
{
    public class NinjaContext:DbContext
    {
        public NinjaContext(){}
        public NinjaContext(string connectionStringName) : base(connectionStringName) { }

        public DbSet<Ninja> Ninjas { get; set; }
    }
}
