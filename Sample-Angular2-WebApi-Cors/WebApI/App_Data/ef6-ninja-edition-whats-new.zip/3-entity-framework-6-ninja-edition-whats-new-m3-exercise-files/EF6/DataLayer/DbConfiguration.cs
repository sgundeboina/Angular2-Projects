﻿using System.Data.Entity;
using System.Data.Entity.SqlServer;

namespace EF6DataLayer
{
  internal class NinjaDbConfiguration : DbConfiguration
  {
    public NinjaDbConfiguration()
    {
      AddInterceptor(new TransientFailureCausingCommandInterceptor());

      SetExecutionStrategy
        (SqlProviderServices.ProviderInvariantName,
          () => new SqlAzureExecutionStrategy());
    }
  }
}